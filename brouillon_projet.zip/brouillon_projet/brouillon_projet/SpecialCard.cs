﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace brouillon_projet
{
    public class SpecialCard : Card
    {
        public SpecialCard(int id, CardType type, CardColor color) : base(id, type, color)
        {
        }
    }
}
